#!/bin/bash
# ================================================================================
# Minecraft Server Auto Launcher - Linux/Mac Version
# ================================================================================

echo "================================"
echo "Minecraft Server Auto Launcher"
echo "================================"
echo ""

# server.jar 파일 찾기
if [ ! -f "server.jar" ]; then
    echo "server.jar 파일을 찾을 수 없습니다."
    echo "현재 폴더의 jar 파일 목록:"
    echo ""
    ls -1 *.jar 2>/dev/null || echo "[jar 파일 없음]"
    echo ""
    read -p "사용할 jar 파일명을 입력하세요: " jarfile
else
    jarfile="server.jar"
fi

if [ ! -f "$jarfile" ]; then
    echo "파일을 찾을 수 없습니다: $jarfile"
    read -p "Press Enter to exit..."
    exit 1
fi

echo ""
echo "서버 파일: $jarfile"
echo "마인크래프트 버전 분석 중..."
echo ""

# 파일명에서 버전 추출
version="unknown"
filename="$jarfile"

# 일반적인 버전 패턴 감지
if echo "$filename" | grep -E "1\.20\.[5-9]" > /dev/null; then
    version="1.20.5+"
elif echo "$filename" | grep -E "1\.20\.[0-4]" > /dev/null; then
    version="1.20"
elif echo "$filename" | grep -E "1\.19" > /dev/null; then
    version="1.19"
elif echo "$filename" | grep -E "1\.18" > /dev/null; then
    version="1.18"
elif echo "$filename" | grep -E "1\.17" > /dev/null; then
    version="1.17"
elif echo "$filename" | grep -E "1\.16" > /dev/null; then
    version="1.16"
elif echo "$filename" | grep -E "1\.15" > /dev/null; then
    version="1.15"
elif echo "$filename" | grep -E "1\.14" > /dev/null; then
    version="1.14"
elif echo "$filename" | grep -E "1\.13" > /dev/null; then
    version="1.13"
elif echo "$filename" | grep -E "1\.(12|11|10|9|8|7)" > /dev/null; then
    version="1.12"
fi

echo "감지된 마인크래프트 버전: $version"

# 버전에 따른 필요 자바 버전 결정
required_java=8
case "$version" in
    "1.20.5+") required_java=21 ;;
    "1.20") required_java=17 ;;
    "1.19") required_java=17 ;;
    "1.18") required_java=17 ;;
    "1.17") required_java=16 ;;
esac

echo "필요한 Java 버전: Java $required_java+"
echo ""

# 설치된 자바 찾기
java_found=0
java_path=""
java_version=0

# Java 명령어 확인 함수
check_java_version() {
    local java_cmd="$1"
    if command -v "$java_cmd" &> /dev/null; then
        local ver=$("$java_cmd" -version 2>&1 | grep -oP 'version "\K\d+' | head -1)
        if [ -z "$ver" ]; then
            # Java 8 형식 (1.8.0)
            ver=$("$java_cmd" -version 2>&1 | grep -oP 'version "1\.\K\d+' | head -1)
        fi
        echo "$ver"
    else
        echo "0"
    fi
}

# 시스템 Java 확인
system_java_ver=$(check_java_version "java")
if [ "$system_java_ver" -ge "$required_java" ] 2>/dev/null; then
    java_path="java"
    java_version="$system_java_ver"
    java_found=1
fi

# macOS Homebrew Java 경로들 확인
if [ $java_found -eq 0 ]; then
    for java_home in /opt/homebrew/opt/openjdk@*/bin/java /usr/local/opt/openjdk@*/bin/java; do
        if [ -f "$java_home" ]; then
            ver=$(check_java_version "$java_home")
            if [ "$ver" -ge "$required_java" ] 2>/dev/null; then
                java_path="$java_home"
                java_version="$ver"
                java_found=1
                break
            fi
        fi
    done
fi

# Linux 일반적인 경로 확인
if [ $java_found -eq 0 ]; then
    for java_home in /usr/lib/jvm/java-*/bin/java; do
        if [ -f "$java_home" ]; then
            ver=$(check_java_version "$java_home")
            if [ "$ver" -ge "$required_java" ] 2>/dev/null; then
                java_path="$java_home"
                java_version="$ver"
                java_found=1
                break
            fi
        fi
    done
fi

if [ $java_found -eq 0 ]; then
    echo "[오류] Java $required_java 이상을 찾을 수 없습니다."
    echo ""
    echo "다음 중 하나를 설치해주세요:"
    case $required_java in
        21) echo "- Java 21: https://adoptium.net/" ;;
        17) echo "- Java 17: https://adoptium.net/" ;;
        16) echo "- Java 16: https://adoptium.net/" ;;
        8) echo "- Java 8: https://adoptium.net/" ;;
    esac
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "[성공] Java $java_version 찾음"
echo "경로: $java_path"
echo ""

# EULA 자동 동의
if [ ! -f "eula.txt" ]; then
    echo "eula=true" > eula.txt
    echo "[자동] EULA 동의 완료"
    echo ""
fi

echo "서버를 시작합니다..."
echo "================================"
echo ""

# 서버 실행
"$java_path" -Xmx12G -Xms4G -jar "$jarfile" nogui

echo ""
read -p "Press Enter to exit..."
